// Define de task ID for each task.
#define SCHEDULER_ID 0
#define BUTTON_DOWN_ID 1
#define BUTTON_UP_ID 2
#define SERVO_ID 5
#define SCREEN_ID 6
#define ADC_ISR_ID 7
#define BUTTON_DOWN_ISR_ID 8
#define BUTTON_UP_ISR_ID 9
#define RACKET_LEFT_ID 10
#define RACKET_RIGHT_ID 11
