// Define de task ID for each task.
#define RACKET_L_X_MIN_POS 4
#define RACKET_L_X_MAX_POS 8

#define RACKET_R_X_MIN_POS 120
#define RACKET_R_X_MAX_POS 124


